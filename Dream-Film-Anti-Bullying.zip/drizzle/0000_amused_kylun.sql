CREATE TABLE `records` (
	`id` text PRIMARY KEY NOT NULL,
	`kind` text NOT NULL,
	`title` text NOT NULL,
	`status` text DEFAULT '构思中' NOT NULL,
	`audience` text DEFAULT '父母' NOT NULL,
	`theme` text DEFAULT '真人出镜' NOT NULL,
	`date` text DEFAULT '' NOT NULL,
	`platform` text DEFAULT '' NOT NULL,
	`body` text DEFAULT '' NOT NULL,
	`notes` text DEFAULT '' NOT NULL,
	`metrics` text DEFAULT '{}' NOT NULL,
	`extra` text DEFAULT '{}' NOT NULL,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL
);
