import { getDb } from '@/db';
import { records } from '@/db/schema';
import { eq } from 'drizzle-orm';
const clean = (value: unknown, max = 20000) => typeof value === 'string' ? value.slice(0,max) : '';
export async function GET() {
  try { return Response.json(await getDb().select().from(records)); }
  catch (e) { return Response.json({error:String(e)}, {status:500}); }
}
export async function POST(request: Request) {
  try {
    const input = await request.json(); const items = Array.isArray(input) ? input : [input];
    if (!items.length || items.length > 50) return Response.json({error:'一次最多保存 50 条'}, {status:400});
    const now = new Date().toISOString(); const created = [];
    for (const item of items) {
      const value = {id:crypto.randomUUID(),kind:['content','activity','template'].includes(clean(item.kind))?clean(item.kind):'content',
        title:clean(item.title,300)||'未命名',status:clean(item.status,100)||'构思中',audience:clean(item.audience,200),
        theme:clean(item.theme,200),date:clean(item.date,100),platform:clean(item.platform,200),body:clean(item.body),
        notes:clean(item.notes),metrics:clean(item.metrics,3000)||'{}',extra:clean(item.extra,10000)||'{}',createdAt:now,updatedAt:now};
      created.push(...await getDb().insert(records).values(value).returning());
    }
    return Response.json(created,{status:201});
  } catch(e) { return Response.json({error:String(e)},{status:500}); }
}
export async function PATCH(request: Request) {
  try {
    const input = await request.json() as Record<string,unknown>; const id = clean(input.id,100);
    if (!id) return Response.json({error:'缺少记录编号'},{status:400});
    const update: Record<string,string> = {updatedAt:new Date().toISOString()};
    for (const field of ['title','status','audience','theme','date','platform','body','notes','metrics','extra'])
      if (field in input) update[field]=clean(input[field],field==='body'?20000:field==='extra'?10000:3000);
    const result=await getDb().update(records).set(update).where(eq(records.id,id)).returning();
    return Response.json(result[0]??null);
  } catch(e) { return Response.json({error:String(e)},{status:500}); }
}
export async function DELETE(request: Request) {
  try { const {id}=await request.json() as {id:string}; await getDb().delete(records).where(eq(records.id,clean(id,100))); return Response.json({ok:true}); }
  catch(e) { return Response.json({error:String(e)},{status:500}); }
}
