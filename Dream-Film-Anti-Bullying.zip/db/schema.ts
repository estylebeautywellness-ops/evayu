import { sqliteTable, text } from 'drizzle-orm/sqlite-core';
export const records = sqliteTable('records', {
  id: text('id').primaryKey(), kind: text('kind').notNull(), title: text('title').notNull(),
  status: text('status').notNull().default('构思中'), audience: text('audience').notNull().default('父母'),
  theme: text('theme').notNull().default('真人出镜'), date: text('date').notNull().default(''),
  platform: text('platform').notNull().default(''), body: text('body').notNull().default(''),
  notes: text('notes').notNull().default(''), metrics: text('metrics').notNull().default('{}'),
  extra: text('extra').notNull().default('{}'), createdAt: text('created_at').notNull(), updatedAt: text('updated_at').notNull(),
});
